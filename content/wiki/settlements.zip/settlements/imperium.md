---
title: "Imperium"
description: "Den femtonde och högsta settlementnivån med maximalt territorium, maximal handelsrabatt och tillgång till Underverk."
category: "Settlements"
order: 15
version: "1.0"
engineVersion: "Settlement Registry"
updatedAt: "2026-07-19"

relatedArticles:
  - category: "settlements"
    article: "kungadome"
    title: "Kungadöme"
    description: "Den fjortonde settlementnivån och föregående steget i settlementets utveckling."
  - category: "buildings"
    article: "underverk"
    title: "Underverk"
    description: "Settlementets högsta specialbyggnad."
---

<SettlementInfoBox settlement="imperium" />

# Imperium

Ett **Imperium** är den femtonde och högsta settlementnivån i GameZone.

På denna nivå har settlementet nått sin maximala territoriella, ekonomiska och administrativa utveckling med ett territorium på **300 block** och en handelsrabatt på **70 %**.

Imperium är den sista settlementnivån och låser upp **Underverk**, settlementets mest prestigefyllda specialbyggnad.

## Territorium

Imperium ger ett territorium med en radie på **300 block** från settlementets registrerade centrum.

Detta är det största territorium som ett settlement kan uppnå.

Settlementets registrerade centrum är permanent och kan inte flyttas.

Det finns ingen fysisk Town Hall som kan förstöras, flyttas eller användas som ett vanligt Minecraft-block.

## Grundbonus

Imperium behåller settlementets permanenta grundbonus på **+15 % Coins** från all reward-eligible produktion.

Grundbonusen gäller:

- Gruvdrift
- Jordbruk
- Skogsbruk
- Boskap
- Fiske
- Byggmaterial
- Alkemi

Bonusar från upplåsta byggnader läggs ovanpå grundbonusen.

Om Monument har färdigställts får settlementets aktiva medlemmar ytterligare **+10 % Coins** från all registrerad manuell produktion.

Om Underverk har färdigställts får settlementets aktiva medlemmar ytterligare **+10 % Coins** från all registrerad manuell produktion.

> [!IMPORTANT]
> Grundbonusen samt bonusar från Monument och Underverk gäller endast settlementets aktiva medlemmar och endast reward-eligible manuell produktion.

## Handelsrabatt

Företag som är registrerade i ett Imperium ger alla spelare en handelsrabatt på **70 %**.

Detta är den högsta handelsrabatten i hela settlementsystemet.

Rabatten påverkar endast köparens slutpris.

Företaget får fortfarande hela sitt satta försäljningspris och mellanskillnaden finansieras av Economy Engine.

Settlementets stadskassa påverkas inte av handelsrabatten.

## Veckounderhåll

Imperium har ett ordinarie veckounderhåll på **250 000 Coins**.

Underhållet dras automatiskt från settlementets stadskassa.

Om settlementet har färdigställt Marknadsplats minskas veckounderhållet med **10 %**.

Det innebär:

- Ordinarie veckounderhåll: **250 000 Coins**
- Minskning: **25 000 Coins**
- Faktiskt veckounderhåll: **225 000 Coins**

Om stadskassan saknar tillräckligt med Coins nedgraderas settlementet automatiskt.

Vid en nedgradering:

- territoriet minskar
- handelsrabatten uppdateras
- nivåbundna funktioner inaktiveras
- byggnader med högre nivåkrav blir inaktiva

Permanenta byggnadsupplåsningar försvinner aldrig.

När settlementet åter når byggnadens nivåkrav aktiveras byggnaden automatiskt igen.

## Byggnader

<SettlementBuildingsPanel group="imperium" />

## Underverk

Imperium låser upp **Underverk**.

Underverk är settlementets högsta specialbyggnad och byggs som ett separat byggprojekt efter att settlementet har nått nivå 15.

När Underverk färdigställs får settlementets aktiva medlemmar:

- **+10 % Coins från all reward-eligible produktion**

Bonusen läggs ovanpå settlementets grundbonus och övriga aktiva byggnadsbonusar.

## Högsta settlementnivån

Imperium är den sista settlementnivån i GameZone.

När ett settlement har nått Imperium finns inga ytterligare nivåer att avancera till.

Settlementet kan därefter fortsätta att:

- färdigställa Underverk
- utveckla sin ekonomi
- driva företag och handel
- expandera sin stadskassa
- förvalta sitt territorium
- använda samtliga funktioner som har låsts upp under settlementets utveckling