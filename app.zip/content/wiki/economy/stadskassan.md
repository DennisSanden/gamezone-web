---
title: "Stadskassan och stadsskatt"
description: "Så fungerar settlementets gemensamma Coins, stadsskatt, skatteöversikt, insättningar, uttag och utbetalningar."
category: "Ekonomi"
order: 3
version: "1.6"
engineVersion: "Economy Engine"
updatedAt: "2026-08-20"
infoboxTitle: "Stadskassan"
infobox:
  standardSkatt: "25 %"
  minstaSkatt: "0 %"
  högstaSkatt: "100 %"
  bestämsAv: "King"
  transaktionsavgift: "7,5 %, eller 2,5 % med Myntförvaring"
---

## Vad är stadskassan?

Stadskassan är settlementets gemensamma Coin-saldo. Pengarna används bland annat till:

- settlementuppgraderingar
- byggnadslicenser
- spelartitlar
- namnbyte och kategoribyte
- köp av mer territorium
- utbetalningar till settlementets invånare

Du öppnar översikten med:

`/settlement treasury`

Menyn visar settlementets saldo och ekonomiska funktioner. Det går inte att sätta in eller ta ut Coins genom menyn. Alla överföringar görs med kommandon.

## Skatteöversikt

När settlementet har låst upp byggnaden [Bank](/wiki/buildings/bank) blir **Skatteöversikten** tillgänglig under Stadskassan.

Översikten visar hur mycket skatt settlementet har fått in och var pengarna kommer från:

- **Total skatt**, all registrerad skatt under den valda perioden
- **Produktionsskatt**, skatt från medlemmarnas godkända produktion
- **Företagsskatt**, skatt från företag registrerade i settlementet
- **Företagslista**, hur mycket varje företag har genererat till stadskassan

Du kan växla mellan tre tidsperioder:

- senaste 7 dagarna
- senaste 30 dagarna
- totalt

> [!NOTE]
> Skatteöversikten är statistik. Pengarna sätts fortfarande in direkt i stadskassan när skatten tas ut.

## Sätta in Coins

Alla aktiva invånare kan sätta in Coins från sitt eget saldo i stadskassan med:

`/settlement deposit <belopp>`

Standardavgiften är **7,5 procent**. Avgiften betalas av spelaren utöver beloppet som sätts in.

Exempel, `/settlement deposit 50000` utan Myntförvaring:

- 50 000 Coins går till stadskassan
- 3 750 Coins tas i transaktionsavgift
- spelaren behöver alltså 53 750 Coins

Med en aktiv [Myntförvaring](/wiki/buildings/myntforvaring) sjunker avgiften till **2,5 procent**. Samma insättning kostar då 1 250 Coins i avgift.

## Ta ut Coins till King

Endast settlementets King kan ta ut Coins från stadskassan till sitt eget saldo:

`/settlement withdraw <belopp>`

Standardavgiften är **7,5 procent** och tas från stadskassan utöver uttaget.

Ett uttag på 50 000 Coins kostar därför totalt 53 750 Coins:

- 50 000 Coins går till King
- 3 750 Coins går i transaktionsavgift

Med aktiv Myntförvaring blir avgiften **2,5 procent**, alltså 1 250 Coins på ett uttag på 50 000.

## Skicka Coins till en invånare

King kan skicka Coins från stadskassan direkt till en aktiv invånare i samma settlement:

`/settlement send <spelare> <belopp>`

Utbetalningen använder samma transaktionsavgift som vanliga uttag, **7,5 procent som standard och 2,5 procent med aktiv Myntförvaring**.

Mottagaren behöver inte vara online, men måste vara registrerad som aktiv invånare i samma settlement.

## Stadsskatt på produktion

När en spelare är medlem i ett settlement och tjänar Coins genom godkänd kategoriproduktion går en andel direkt till stadskassan.

Standardnivån är **25 procent**. Settlementets King kan ändra stadsskatten mellan **0 och 100 procent** med:

`/settlement tax <procent>`

Exempel:

`/settlement tax 20`

En låg stadsskatt låter invånarna behålla mer av sina produktionsintäkter och kan göra settlementet mer attraktivt för nya medlemmar. En hög stadsskatt fyller stadskassan snabbare när settlementet sparar till en större investering.

## Krigsskuld

Om settlementet förlorar ett Settlement War och inte kan betala hela krigsskadeståndet direkt uppstår en **krigsskuld**.

Så länge skulden finns går **50 procent av framtida systemgenererade intäkter som annars skulle ha gått till stadskassan** till avbetalning. Det gäller bland annat produktionsskatt och settlementets intäkter från företagshandel. Den andra halvan går fortfarande till den egna stadskassan.

Att sänka stadsskatten till 0 procent skriver inte av skulden. Skulden ligger kvar tills den faktiskt har betalats. Har settlementet flera skulder betalas den äldsta först.

Läs nivåbelopp och hela modellen på sidan [Krigssystemet](/wiki/war/krigssystemet).

## Skillnaden mot Server TAX

Stadsskatt tas från invånarnas produktionsintäkter och går till stadskassan.

Detta är inte samma sak som [Server TAX på företagshandel](/wiki/economy/server-tax). Server TAX tas när företag säljer items till andra spelare och går till servern. Grundnivån styrs av settlementets level och kan sänkas av bland annat företagslicensen.
