---
title: "Köping"
description: "Den sjätte settlementnivån där Kyrkan ger en permanent bonus till all registrerad produktion."
category: "Settlements"
order: 15
version: "1.0"
engineVersion: "Settlement Registry"
updatedAt: "2026-07-18"


relatedArticles:
  - category: "settlements"
    article: "samhalle"
    title: "Samhälle"
    description: "Den femte settlementnivån och föregående steg i settlementets utveckling."
  - category: "settlements"
    article: "stad"
    title: "Stad"
    description: "Den sjunde settlementnivån och nästa steg i settlementets utveckling."
---

<SettlementInfoBox settlement="koping" />

# Köping

En **Köping** är den sjätte settlementnivån i GameZone.

På denna nivå växer settlementets territorium och Server TAX ytterligare. Köping låser även upp **Kyrka**, en permanent specialbyggnad som förstärker all registrerad produktion för settlementets aktiva medlemmar.

## Territorium

Köping ger ett territorium med en radie på **63 block** från settlementets registrerade centrum.

Territoriet utökas automatiskt när settlementet når nivå 6.

Settlementets registrerade centrum är permanent och kan inte flyttas.

Det finns ingen fysisk Town Hall som kan förstöras, flyttas eller användas som ett vanligt Minecraft-block.

## Produktion

Köping behåller settlementets permanenta grundbonus på **Coins endast från vald kategori** från all reward-eligible produktion.

Grundbonusen gäller:

- Gruvdrift
- Jordbruk
- Skogsbruk
- Boskap
- Fiske
- Byggmaterial
- Alkemi



> [!IMPORTANT]
> Produktion utanför den valda kategorin kan fortfarande användas, men ger inga Coins.



## Byggnader

<SettlementBuildingsPanel group="koping" />

## Nästa nivå

<SettlementUpgradePanel upgradeKey="koping-till-stad" />
